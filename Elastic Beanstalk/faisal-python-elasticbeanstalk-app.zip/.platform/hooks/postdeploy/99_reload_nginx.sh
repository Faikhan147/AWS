#!/bin/bash

# Reload NGINX after every deploy
sudo systemctl reload nginx
